#include <fstream>
#include <iostream>

#include "GameController.h"

void chooseCommand(BlockFall& game, std::string &command);
bool GameController::play(BlockFall& game, const string& commands_file){
    // TODO: implement the gameplay here while reading the commands from the input file given as the 3rd command-line
    //       argument. the return value represents if the gameplay was successful or not: false if game over,
    //       true otherwise.

    std::ifstream ifs{commands_file};
    std::string command;

    if(!ifs.is_open()) {
        std::cerr << "Error opening file: " << commands_file << "\n";
        exit(-1);
    }

    game.place_block(game.initial_block);

    while(ifs >> command) {
        chooseCommand(game, command);
    }
    return false;
}

void chooseCommand(BlockFall& game, std::string &command) {
    std::cout << "Command called: " << command << "\n";
    if(command == "PRINT_GRID") {
        game.print_grid();
        std::cout << "\n";
        return;
    }
    if(command == "ROTATE_RIGHT") {
        game.rotate_right();
        return;
    }
    if(command == "ROTATE_LEFT") {
        game.rotate_left();
        return;
    }
    if(command == "MOVE_RIGHT") {
        game.move_right();
        return;
    }
    if(command == "MOVE_LEFT") {
        game.move_left();
        return;
    }
    if(command == "DROP") {
        game.drop();
        return;
    }
    if(command == "GRAVITY_SWITCH") {
        return;
    }
    std::cout << "Unknown command: " << command;
}
