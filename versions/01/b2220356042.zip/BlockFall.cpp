#include "BlockFall.h"
#include <fstream>
#include <sstream>
#include <iostream>

Block* rotate90CW(Block* block);
bool isNewRotation(Block* head, Block* rotation);
void addRotation(Block* head, Block* rotation);
void createRotations(Block* head);
std::vector<std::vector<std::vector<bool>>> getShapes(std::ifstream &ifs);

BlockFall::BlockFall(string grid_file_name, string blocks_file_name, bool gravity_mode_on, const string &leaderboard_file_name, const string &player_name) : gravity_mode_on(
        gravity_mode_on), leaderboard_file_name(leaderboard_file_name), player_name(player_name) {
    initialize_grid(grid_file_name);
    read_blocks(blocks_file_name);
//    leaderboard.read_from_file(leaderboard_file_name);
}

void BlockFall::read_blocks(const string &input_file) {
    // TODO: Read the blocks from the input file and initialize "initial_block" and "active_rotation" member variables
    // TODO: For every block, generate its rotations and properly implement the multilevel linked list structure
    //       that represents the game blocks, as explained in the PA instructions.
    // TODO: Initialize the "power_up" member variable as the last block from the input file (do not add it to the linked list!)
    std::ifstream ifs{input_file};

    if (!ifs.is_open()) {
        std::cerr << "Error opening file: " << input_file << "\n";
        exit(-1);
    }

    auto shapes = getShapes(ifs);
    for (int i = 0; i < shapes.size() - 1; ++i) {
        Block* newBlock = new Block();
        newBlock->shape = shapes.at(i);
        if(initial_block == nullptr) {
            initial_block = newBlock;
        } else {
            Block* temp = initial_block;
            while(temp->next_block != nullptr) {
                temp = temp->next_block;
            }
            temp->next_block = newBlock;
        }
    }

    power_up = shapes[shapes.size() - 1];
    active_rotation = initial_block;

    for (Block* block = initial_block; block != nullptr; block = block->next_block) {
        createRotations(block);
        Block* temp = block;
        do {
            for (int i = 0; i < temp->shape.size(); ++i) {
                for (int j = 0; j < temp->shape[0].size(); ++j) {
                    std::cout << temp->shape[i][j] << " ";
                }
                std::cout << "\n";
            }
            std::cout << "\n";
            temp = temp->right_rotation;
        } while (temp != block);
    }
}

void BlockFall::initialize_grid(const string &input_file) {
    // TODO: Initialize "rows" and "cols" member variables
    // TODO: Initialize "grid" member variable using the command-line argument 1 in main
    std::ifstream ifs{input_file};
    std::string line;

    if (!ifs.is_open()) {
        std::cerr << "Error opening file: " << input_file << "\n";
        exit(-1);
    }

    int num;
    while(getline(ifs, line)) {
        std::vector<int> row;
        std::stringstream ss{line};
        while(ss >> num) {
            row.push_back(num);
        }
        grid.push_back(row);
    }

    rows = static_cast<int>(grid.size());
    cols = static_cast<int>(grid[0].size());
}

BlockFall::~BlockFall() {
    // TODO: Free dynamically allocated memory used for storing game blocks
}

Block* rotate90CW(Block* block) {
    size_t row = block->shape.size();
    size_t col = block->shape[0].size();
    std::vector<std::vector<bool>> shape;
    for (int j = 0; j < col; ++j) {
        std::vector<bool> rotRow;
        for (int i = row - 1; i >= 0; i--) {
            rotRow.push_back(block->shape[i][j]);
        }
        shape.push_back(rotRow);
    }
    Block* rotation = new Block();
    rotation->shape = shape;
    return rotation;
}

void createRotations(Block* head) {
    Block* temp = head;
    std::vector<Block*> garbageRotations;
    for (int i = 0; i < 3; ++i) {
        temp = rotate90CW(temp);
        if(isNewRotation(head, temp)) {
            addRotation(head, temp);
        } else {
            garbageRotations.push_back(temp);
        }
    }

    for (auto & garbageRotation : garbageRotations) {
        delete garbageRotation;
    }

    Block* tail = head;
    while(tail->right_rotation != nullptr) {
        tail = tail->right_rotation;
    }
    head->left_rotation = tail;
    tail->right_rotation = head;
}

void addRotation(Block* head, Block* rotation) {
    Block* temp = head;
    while(temp->right_rotation != nullptr) {
        temp = temp->right_rotation;
    }
    temp->right_rotation = rotation;
    rotation->left_rotation = temp;
}

bool isNewRotation(Block* head, Block* rotation) {
    for(Block* block = head; block != nullptr; block = block->right_rotation) {
        if(*block == *rotation)
            return false;
    }
    return true;
}

std::vector<std::vector<std::vector<bool>>> getShapes(std::ifstream &ifs) {
    std::string str;
    std::vector<std::vector<std::vector<bool>>> shapes;
    std::vector<std::vector<bool>> shape;
    while(ifs >> str) {
        std::vector<bool> row;
        for (char i : str) {
            switch (i) {
                case '1':
                    row.push_back(true);
                    break;
                case '0':
                    row.push_back(false);
                    break;
                case '[':
                    shapes.push_back(shape);
                    shape.clear();
                    break;
                default:
                    continue;
            }
        }
        shape.push_back(row);
    }
    shapes.push_back(shape);
    shapes.erase(shapes.begin());
    return shapes;
}