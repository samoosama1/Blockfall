#include "GameController.h"

bool GameController::play(BlockFall& game, const string& commands_file){

    // TODO: implement the gameplay here while reading the commands from the input file given as the 3rd command-line
    //       argument. the return value represents if the gameplay was successful or not: false if game over,
    //       true otherwise.

    return false;
}



